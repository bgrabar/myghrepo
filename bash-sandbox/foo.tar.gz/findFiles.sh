#!/bin/bash
find -name "doc"
