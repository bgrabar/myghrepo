#!/bin/bash
car=toyota
echo $car
echo "$car"
echo '$car'
echo "car"
echo 'car'