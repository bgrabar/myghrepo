#!/bin/bash

# prints out the number of arguments


if [ "$#" -eg 0 ]; then
    echo "usage: $0 "
    echo "Type Enter to exit."
    exit
fi


for 

for dots in 1 2 3 4 5 6 7 8 9 10; do
    echo -n "."
    echo "System clean."
done


echo "The argument is $1"
