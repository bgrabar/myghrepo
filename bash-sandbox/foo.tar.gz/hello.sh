#!/bin/bash
echo "Hello World as run from bash.script"
