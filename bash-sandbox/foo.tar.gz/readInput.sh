#!/bin/bash

echo -n "Enter a word: "
#reads the keyboard entry
read word
echo "You entered $word."

read -p "Enter your first and last names: " first last
echo "First name is $first"
echo "Last name is $last"






