#!/bin/bash
mkdir TEST
cd TEST
touch file1 file2 file3
