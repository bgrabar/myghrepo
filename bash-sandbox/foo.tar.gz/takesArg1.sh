#!/bin/bash
x=7
y=4
echo "the value was $1"
echo "the value now is $2"
echo "the value of x is $x"
echo "the value of y is $y"
